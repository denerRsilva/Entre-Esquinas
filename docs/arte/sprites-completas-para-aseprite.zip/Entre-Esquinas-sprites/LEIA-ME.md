# Sprites do Entre Esquinas para editar no Aseprite

Diretriz: pixel art em **32 × 32 pixels reais por célula/quadro**. Personagem
com 4 direções × 4 quadros: folha final 128 × 128. Objetos maiores são compostos
por células 32 × 32, mantendo a densidade e a perspectiva do projeto.

Este pacote conserva a arte ATUAL, ainda ampliada/provisória. Nada foi reduzido,
redesenhado ou substituído no jogo. A base é o commit 343d450.

## Pastas

- **01-originais**: 37 imagens/fontes PNG e SVG, copiadas byte a byte
  de godot/arte, godot/personagens e godot/mundo. Inclui atlas atuais, materiais
  antigos e variantes locais existentes (identificadas por no_git em originais.csv).
- **02-recortes**: partes extraídas sem reamostragem dos atlas: pisos, paredes,
  móveis, decoração, ingredientes, receitas, pratos, bancadas e frames de
  personagem. Há também os ícones SVG atuais rasterizados para edição em PNG.
- **03-renderizados**: aparência real em escala nativa da Godot, incluindo todas
  as peças do catálogo e suas quatro orientações, personagens, objetos
  desenhados por código, exterior, panelas, talher, estrelas e estados dos pratos.
- **04-referencias**: manequim, estudos e pranchas de tilesets. Não confundir
  estudos antigos com peças atualmente instaladas no jogo.
- **05-fontes**: cenas, SpriteFrames, TileSet, scripts e diretrizes que explicam
  recortes, pivôs, encaixes e desenho procedural. Não é uma cópia completa do jogo.

## Por onde começar

Pisos atuais: 02-recortes/pisos/madeira-taverna.png e ceramica-cozinha.png
(128 × 128 originais). Paredes: 02-recortes/paredes, também com o SVG original.
Outros mapas: pisos/mapas-40px contém cada tile distinto de rua/estoque/mapa
antigo; tiles-de-mapas.json conserva a associação de cada célula ao PNG.

Móveis: use indice-sprites.csv para encontrar o nome de cada recorte. A mesa
de trabalho atual é mesa-trabalho-atual.png; os desenhos antigos de corte e
empratamento do atlas permanecem como estudos identificados. Bancadas atuais:
01-originais/godot/arte/modular/bancadas-piskel.png, recortes em bancadas e
exportações counterThin/counterWide em 03-renderizados/moveis.

Personagens: fontes ampliadas em 01-originais/godot/arte/taverna; recortes de
quadros em 02-recortes/personagens. As folhas renderizadas têm células 96 × 96
com margem, **não são sprites prontas em 32 × 32**. Os frames são exportados
na ordem real do SpriteFrames (baixo, esquerda, direita, cima), inclusive
repetições de quadros usadas na animação. Regiões originais fracionárias de
313,5 px são mantidas no manifesto e recortadas com borda inteira, sem reduzir.

## Margens e conteúdo dinâmico

Exportações de móveis têm canvas 256 × 256 com pivô (128,224), para não cortar
objetos esticados nas rotações. Personagens têm canvas 96 × 96 e pivô (48,80).
Essas margens transparentes não são a resolução-alvo. Prefira os recortes do
atlas ou remova as margens antes de ajustar a arte/canvas à grade 32 × 32.

O kit de empratamento não tem decoração fixa por decisão atual: seus quatro
PNGs isolados são transparentes intencionalmente. Os pratos reais são camadas
dinâmicas; veja os exemplos pratos-00/01/10/11/20, além do prato individual.
Pratos com comida usam as imagens das receitas; panelas cheias usam a mesma
panela com a camada de conteúdo. Não desenhar estoque fixo como se fosse real.

## Reenvio e verificação

Preserve nomes e identificação ao reenviar as edições. Você pode enviar PNGs
editados, sheets novas com a grade descrita, e/ou arquivos .aseprite. Não há
fontes .aseprite anteriores no repositório; os arquivos fonte existentes são
PNG/SVG e os recursos/scripts incluídos. Após as edições será necessário
adaptar recortes, SpriteFrames, pivôs e TileSets; simplesmente substituir um
atlas grande por um pequeno invalidaria as coordenadas atuais.

originais.csv traz dimensões e SHA256 dos originais. indice-sprites.csv permite
buscar nomes. recortes-e-renderizacoes.json registra cada extração/renderização;
SHA256SUMS.txt confere todos os arquivos. A grade lógica atual do jogo é 40
unidades e não foi mudada por esta exportação.
